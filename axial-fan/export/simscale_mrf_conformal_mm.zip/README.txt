Units: mm. Rotation axis: Z through (0,0,0).
Positive omega about +Z (right-hand rule) blows air toward +Z (inlet at -Z).
MRF zone: cylinder R=247.5 mm, z from -70 to 42.5 mm.
Bodies and faces:
  flow_static: stator_walls, mrf_interface, duct_walls, inlet, outlet
  flow_rotating: mrf_interface, rotor_walls
Upload with "Facet split" OFF so each named solid stays one face.
