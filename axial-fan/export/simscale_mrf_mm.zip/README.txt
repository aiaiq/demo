Units: mm. Rotation axis: Z through (0,0,0).
Positive omega about +Z (right-hand rule) blows air toward +Z (inlet at -Z).
MRF zone: cylinder R=247.5 mm, z from -70 to 42.5 mm.
Bodies: flow_static (stationary fluid), flow_rotating (MRF fluid).
Faces: inlet, outlet, farfield, stator_walls, rotor_walls, mrf_interface.
Upload with "Facet split" OFF so each named solid stays one face.
