Units: m. Rotation axis: Z through (0,0,0).
Positive omega about +Z (right-hand rule) blows air toward +Z (inlet at -Z).
MRF zone: cylinder R=247.5 mm, z from -70 to 42.5 mm.
Bodies and faces:
  flow_region: stator_walls, rotor_walls, duct_walls, inlet, outlet
  rotating_zone: rotating_zone
Upload with "Facet split" OFF so each named solid stays one face.
